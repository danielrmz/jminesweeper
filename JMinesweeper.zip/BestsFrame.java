import javax.swing.*;

public class BestsFrame extends JDialog {

	/**
	 * Constante de Eclipse
	 */
	private static final long serialVersionUID = 1L;

	public BestsFrame() {
		super();
		// TODO Auto-generated constructor stub
	}

}
